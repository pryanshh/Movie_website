const navBar = document.querySelector(".sidebar"),
  menuBtns = document.querySelectorAll(".menu-icon"),
  overlay = document.querySelector(".overlay");

menuBtns.forEach((menuBtn) => {
  menuBtn.addEventListener("click", () => {
    navBar.classList.toggle("open");
  });
});

overlay.addEventListener("click", () => {
  navBar.classList.remove("open");
});

// slide 
document.addEventListener("DOMContentLoaded", function () {
  const carousel = document.querySelector(".carousel");
  const carouselCards = document.querySelectorAll(".card");
  const totalCards = carouselCards.length;
  let currentIndex = 0;
  let cardWidth = carousel.offsetWidth; // Update cardWidth to the carousel width

  function slideNext() {
    currentIndex = (currentIndex + 1) % totalCards;
    carousel.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
  }

  function slidePrevious() {
    currentIndex = (currentIndex - 1 + totalCards) % totalCards;
    carousel.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
  }

  setInterval(slideNext, 3000);

  // Add event listeners for previous and next buttons (if you have them)
});
// trending

const nav = document.querySelector("nav"),
searchIcon = document.querySelector("#searchIcon");

searchIcon.addEventListener("click", () => {
  nav.classList.toggle("openSearch");

  if (nav.classList.contains("openSearch")) {
    return searchIcon.classList.replace("fa-magnifying-glass", "fa-xmark");
  }
  searchIcon.classList.replace("fa-xmark", "fa-magnifying-glass");
});