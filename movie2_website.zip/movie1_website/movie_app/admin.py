from django.contrib import admin
from .models import Genre, Movie, Season, Episode

class SeasonInline(admin.TabularInline):
    model = Season

class EpisodeInline(admin.TabularInline):
    model = Episode

class MovieAdmin(admin.ModelAdmin):
    inlines = [SeasonInline]

class SeasonAdmin(admin.ModelAdmin):
    inlines = [EpisodeInline]

admin.site.register(Genre)
admin.site.register(Movie, MovieAdmin)
admin.site.register(Season, SeasonAdmin)
admin.site.register(Episode)