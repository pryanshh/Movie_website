from django.shortcuts import render, get_object_or_404
from .models import Movie, Season, Episode
import random

def home(request):
    movies = Movie.objects.all() 
    trending_movies = Movie.objects.order_by('-views')[:11]
    random_movie = random.choice(movies)
    english_dub_movies = movies.filter(is_English_dub=True)
    hindi_dub_movies = movies.filter(is_Hindi_dub=True)
    recent_uploads = Movie.objects.order_by('-date')[:11]
    Banner_obj = Movie.objects.order_by('-date')[:4]

    context = {
        'english_dub_movies': english_dub_movies,
        'hindi_dub_movies': hindi_dub_movies,
        'recent_uploads': recent_uploads,
        'trending_movies': trending_movies,
        'movies': movies,
        'random_movie': random_movie,
        'banner': Banner_obj,
    }
    return render(request, 'home.html', context)

def movie_detail(request, movie_title):
    movie = get_object_or_404(Movie, title__iexact=movie_title.replace('-', ' '))
    random_movies = Movie.objects.order_by('?')[:11]
    movie.views += 1
    movie.save()
    
    if movie.is_series:
        seasons = movie.season_set.all()
        episodes = Episode.objects.filter(season__in=seasons)
    else:
        seasons = None
        episodes = None

    context = {
        'movie': movie,
        'seasons': seasons,
        'episodes': episodes,
        'random_movies': random_movies,
    }

    return render(request, 'movie_detail.html', context)


def trending_movies(request):
    trending_movies = Movie.objects.order_by('-views')
    return render(request, 'trending_movies.html', {'movies': trending_movies})

def movie_list(request):
    movies = Movie.objects.all()
    return render(request, 'movie_list.html', {'movies': movies})

def series_list(request):
    series = Movie.objects.filter(is_series=True)
    return render(request, 'series_list.html', {'series': series})
    
def recent_upload(request):
    recent = Movie.objects.order_by('-date')
    return render(request, 'recent_upload.html', {'recent': recent})