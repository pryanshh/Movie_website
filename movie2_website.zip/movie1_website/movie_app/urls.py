from django.urls import path
from . import views

app_name = 'movie_app'  

urlpatterns = [
    path('', views.home, name='home'),  
    path('movie/<str:movie_title>/', views.movie_detail, name='movie_detail'),
   path('trending/', views.trending_movies, name='trending_movies'),
    path('movies/', views.movie_list, name='movie_list'),
    path('series/', views.series_list, name='series_list'),
    path('recent/', views.recent_upload, name='recent_upload'),
]
