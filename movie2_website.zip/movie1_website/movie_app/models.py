from django.db import models
from django.utils import timezone
from datetime import datetime, timedelta

#create model here
class Genre(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Movie(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    rating = models.FloatField()
    genres = models.ManyToManyField(Genre)
    language = models.CharField(max_length=50)
    views = models.PositiveIntegerField(default=0)
    image = models.ImageField(upload_to='movie_images/')
    is_series = models.BooleanField(default=False)
    use_iframe = models.BooleanField(default=False)
    iframe_embed_code = models.URLField(blank=True)
    video_file = models.FileField(upload_to='movie_videos/', blank=True)
    is_English_dub = models.BooleanField(default=False)
    is_Hindi_dub = models.BooleanField(default=False)
    date = models.DateTimeField(auto_now_add=True)
    
    def upload_time_formatted(self):
      now = timezone.now()
      difference= now - self.date
      days = difference.days
      hours = difference.seconds // 3600
      
      if days >= 1:
        if days == 1:
          return '1 day ago'
        else:
          return f'{days} days ago'
      else:
        if hours == 1:
          return '1 hour ago'
        else:
          return f'{hours} hours ago'

    def __str__(self):
        return self.title

class Season(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    date = models.DateTimeField(auto_now_add=True)
    
    def upload_time_formatted(self):
      now = timezone.now()
      difference= now - self.date
      days = difference.days
      hours = difference.seconds // 3600
      
      if days >= 1:
        if days == 1:
          return '1 day ago'
        else:
          return f'{days} days ago'
      else:
        if hours == 1:
          return '1 hour ago'
        else:
          return f'{hours} hours ago'
          
    def __str__(self):
        return f"{self.movie.title} - Season {self.title}"

class Episode(models.Model):
    season = models.ForeignKey(Season, related_name='episodes', on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    use_iframe = models.BooleanField(default=False)
    iframe_embed_code = models.URLField(blank=True)
    video_file = models.FileField(upload_to='episode_videos/', blank=True)
    date = models.DateTimeField(auto_now_add=True)
    
    def upload_time_formatted(self):
      now = timezone.now()
      difference= now - self.date
      days = difference.days
      hours = difference.seconds // 3600
      
      if days >= 1:
        if days == 1:
          return '1 day ago'
        else:
          return f'{days} days ago'
      else:
        if hours == 1:
          return '1 hour ago'
        else:
          return f'{hours} hours ago'

    def __str__(self):
        return f"{self.season} - Episode {self.title}"
